API_KEY = "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"
INPUT_TYPES = ["Payment Contracts"]
TYPE_DESCRIPTIONS = [
    "Facilitates fund transfers based on conditions."
]
TEMPERATURES = [0.1]
MODELS = "gpt-3.5-turbo-0125"
